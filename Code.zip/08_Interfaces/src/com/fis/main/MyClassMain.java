package com.fis.main;

import com.fis.pojo.MyClass;

public class MyClassMain {
	public static void main(String[] args) {
		MyClass myClass = new MyClass();
		myClass.display();
		myClass.show();
		myClass.print();
	}
}
