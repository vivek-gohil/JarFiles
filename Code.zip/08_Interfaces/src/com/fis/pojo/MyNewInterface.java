package com.fis.pojo;

public interface MyNewInterface {
	void show();
}
