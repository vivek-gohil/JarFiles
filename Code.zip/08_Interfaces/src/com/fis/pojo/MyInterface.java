package com.fis.pojo;

public interface MyInterface {
	void display();
	
	default void print() {
		System.out.println("default method ");
	}
}
