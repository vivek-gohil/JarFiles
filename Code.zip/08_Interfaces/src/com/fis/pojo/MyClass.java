package com.fis.pojo;

public class MyClass implements MyInterface, MyNewInterface {
	@Override
	public void display() {
		System.out.println("We are in display method");
	}

	@Override
	public void show() {
		System.out.println("We are in show method");
	}

	@Override
	public void print() {
		System.out.println("We are in print method");
	}
}
