package com.fis.pojo;

public class Greeter extends MyAbstractClass {
	@Override
	public void greet() {
		// TODO Auto-generated method stub

	}
}
