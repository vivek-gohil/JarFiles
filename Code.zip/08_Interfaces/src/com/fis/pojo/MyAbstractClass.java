package com.fis.pojo;

public abstract class MyAbstractClass {
	public abstract void greet();
}
