package com.fis.main;

import java.util.HashSet;
import java.util.Scanner;

import com.fis.util.UserNameUtil;

public class UserNameMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		UserNameUtil nameUtil = new UserNameUtil();
		String name;
		int choice;
		boolean result;
		String continueChoice;

		do {
			System.out.println("Menu");
			System.out.println("Press 1.Add New Name");
			System.out.println("Press 2.Display All Names");
			System.out.println("Press 3.Delete/Remove name");
			System.out.println("Press 4.Search and print name");
			choice = scanner.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter Name");
				name = scanner.next();
				result = nameUtil.addName(name);
				if (result) {
					System.out.println(name + " is added into Set");
				} else
					System.out.println(name + " is already present or failed to add new name");
				break;

			case 2:
				System.out.println("Names from collections");
				HashSet<String> names = nameUtil.getAllNames();
				for (String tempName : names) {
					System.out.println(tempName);
				}
				break;
			case 3:
				System.out.println("Enter Name to remove");
				name = scanner.next();
				result = nameUtil.removeName(name);
				if (result) {
					System.out.println(name + " is removed from set");
				} else
					System.out.println(name + " is not found / failed to remove name");
				break;
			case 4:
				System.out.println("Enter Name to search");
				name = scanner.next();
				result = nameUtil.searchName(name);
				if (result) {
					System.out.println(name + " is present in set");
				} else
					System.out.println(name + " is not found");
				break;
			default:
				System.out.println("Invlaid choice");
				break;
			}
			System.out.println("Do you want to continue?");
			continueChoice = scanner.next();
		} while (continueChoice.equals("yes"));
	}
}
