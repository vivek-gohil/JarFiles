package com.fis.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeMap;
import java.util.TreeSet;

public class CollectionMain {
	public static void main(String[] args) {
		System.out.println("1.ArrayList");
		ArrayList<String> nameList = new ArrayList<String>();
		nameList.add("Asmitha");
		nameList.add("Gururaj");
		nameList.add("Naveen");
		nameList.add("Fathima");
		nameList.add("Naveen");
		nameList.add("Asmitha");
		System.out.println(nameList);
		System.out.println("-------------");
		for (String name : nameList) {
			System.out.println(name);
		}

		System.out.println("2.HashSet");
		HashSet<String> nameSet = new HashSet<String>();
		nameSet.add("Asmitha");
		nameSet.add("Gururaj");
		nameSet.add("Naveen");
		nameSet.add("Fathima");
		nameSet.add("Naveen");
		nameSet.add("Asmitha");
		System.out.println(nameSet);
		for (String name : nameSet) {
			System.out.println(name);
		}
		nameSet.remove("Naveen");
		System.out.println("After remove Naveen");
		for (String name : nameSet) {
			System.out.println(name);
		}
		System.out.println("3.TreeSet");
		TreeSet<Integer> numberSet = new TreeSet<Integer>();
		numberSet.add(14);
		numberSet.add(6);
		numberSet.add(81);
		numberSet.add(6);
		numberSet.add(11);
		System.out.println(numberSet);
		System.out.println("Using For eache loop");
		for (Integer num : numberSet) {
			System.out.println(num);
		}

		System.out.println("4.HashMap");
		HashMap<Integer, String> employeeMap = new HashMap<Integer, String>();
		employeeMap.put(101, "Vivek");
		employeeMap.put(102, "Abhishek");
		employeeMap.put(103, "Gokul");
		employeeMap.put(101, "Manish");
		System.out.println(employeeMap);
		System.out.println("Retrive value using key");
		String name = employeeMap.get(103);
		System.out.println(name);

		System.out.println("5.TreeMap");
		TreeMap<Integer, String> employeeTreeMap = new TreeMap<Integer, String>();
		employeeTreeMap.put(104, "Vivek");
		employeeTreeMap.put(102, "Abhishek");
		employeeTreeMap.put(103, "Gokul");
		employeeTreeMap.put(101, "Manish");
		System.out.println(employeeTreeMap);
	}
}
