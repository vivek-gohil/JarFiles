package com.fis.util;

import java.util.HashSet;

public class UserNameUtil {
	private HashSet<String> nameSet = new HashSet<String>();

	public boolean addName(String name) {
		boolean result = nameSet.add(name);
		return result;
	}

	public HashSet<String> getAllNames() {
		return nameSet;
	}

	// create new method to remove name :: accept param and return the result
	public boolean removeName(String name) {
		boolean result = nameSet.remove(name);
		return result;
	}

	// create new method to search name from the set :: accpet param and return the
	// result(boolean)
	public boolean searchName(String name) {
		boolean result = nameSet.contains(name);
		return result;
	}
}
