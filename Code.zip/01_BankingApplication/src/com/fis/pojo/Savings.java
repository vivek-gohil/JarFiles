package com.fis.pojo;

public class Savings extends Account {
	private boolean isSalary;

	@Override
	public boolean withdraw(double amount) {
		// if isSalary is true the withdraw everything else keep minimum 1500 as balance
		if (amount > 0 && isSalary == true && amount <= getBalance()) {
			setBalance(getBalance() - amount);
			return true;
		}

		if (amount > 0 && isSalary == false && amount <= getBalance() && getBalance() - amount >= 1500) {
			setBalance(getBalance() - amount);
			return true;
		}
		return false;
	}

	@Override
	public boolean deposit(double amount) {
		if (amount > 0) {
			setBalance(getBalance() + amount);
			return true;
		}
		return false;
	}

	public boolean isSalary() {
		return isSalary;
	}

	public void setSalary(boolean isSalary) {
		this.isSalary = isSalary;
	}

	@Override
	public String toString() {
		return "Savings [isSalary=" + isSalary + ", getAccountNumber()=" + getAccountNumber() + ", getName()="
				+ getName() + ", getBalance()=" + getBalance() + "]";
	}

}
