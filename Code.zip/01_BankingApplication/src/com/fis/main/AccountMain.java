package com.fis.main;

import com.fis.pojo.Account;

public class AccountMain {
	public static void main(String[] args) {
		Account account = new Account();

//		account.accountNumber = 101;
//		account.name = "Vivek Gohil";
//		account.balance = 1000;
		account.setAccountNumber(101);
		account.setName("Vivek Gohil");
		account.setBalance(1000);

//		System.out.println("Account Number :: " + account.accountNumber);
//		System.out.println("Name :: " + account.name);
//		System.out.println("Balance :: " + account.balance);

		System.out.println("Account Number :: " + account.getAccountNumber());
		System.out.println("Name :" + account.getName());
		System.out.println("Balance :: " + account.getBalance());

	}

}
