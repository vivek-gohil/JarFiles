package com.fis.main;

import com.fis.pojo.Account;

public class AccountMainV2 {
	public static void main(String[] args) {

		// Reference , Variable of type Account
		Account account = null;

		// We are creating new object of Account and assing to the account reference
		// Whenever we create objects constructor will get called.
		account = new Account();

		account.setAccountNumber(102);
		account.setName("Kumar Manish");
		account.setBalance(2000);

		String data = account.toString();
		System.out.println(data);

		System.out.println(account.toString());
		// System.out.println(account.toString());
		

	}
}
