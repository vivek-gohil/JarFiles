package com.fis.main;

import java.util.Scanner;

import com.fis.pojo.Account;
import com.fis.pojo.Savings;

public class AccountMainV4 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		int accountNumber;
		String name, continueChoice;
		double balance, amount;
		int choice;
		boolean result, isSalary;

		System.out.println("Enter account number");
		accountNumber = scanner.nextInt();
		System.out.println("Enter Name");
		name = scanner.next();
		System.out.println("Enter balance");
		balance = scanner.nextDouble();
		System.out.println("Do you want to open salary account- true or false");
		isSalary = scanner.nextBoolean();

//		Account account = new Account();
//		account.setAccountNumber(accountNumber);
//		account.setName(name);
//		account.setBalance(balance);
		Savings savings = new Savings();
		savings.setAccountNumber(accountNumber);
		savings.setName(name);
		savings.setBalance(balance);
		savings.setSalary(isSalary);

		System.out.println(savings);

		do {
			System.out.println("1. Deposit");
			System.out.println("2. Withdraw");
			System.out.println("3. Check Balance");
			System.out.println("Enter your choice");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter amount to deposit");
				amount = scanner.nextDouble();
				result = savings.deposit(amount);
				if (result)
					System.out.println("Transaction success");
				else
					System.out.println("Transaction Failed");
				break;
			case 2:
				System.out.println("Enter amount to withdraw");
				amount = scanner.nextDouble();
				result = savings.withdraw(amount);
				if (result)
					System.out.println("Transaction success");
				else
					System.out.println("Transaction Failed");
				break;
			case 3:
				System.out.println("Balance :: " + savings.getBalance());
				break;
			default:
				System.out.println("Invalid choice");
				break;
			}
			System.out.println("Do you want to continue?");
			continueChoice = scanner.next();
		} while (continueChoice.equals("yes"));

	}
}
