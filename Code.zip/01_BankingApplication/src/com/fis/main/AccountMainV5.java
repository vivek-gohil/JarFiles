package com.fis.main;

import com.fis.pojo.Current;

public class AccountMainV5 {
	public static void main(String[] args) {
		boolean result;

		Current current = new Current();
		current.setAccountNumber(101);
		current.setName("Vivek Gohil");
		current.setBalance(10000);
		current.setOverdraftBalance(50000);

		System.out.println("Withdraw(5000)");
		result = current.withdraw(5000);
		if (result) {
			System.out.println("Transaction Success");
		} else
			System.out.println("Transaction Failed");
		System.out.println("Balance :: " + current.getBalance()); //5000
		System.out.println("Overdraft Balance :: " + current.getOverdraftBalance()); //50000
		System.out.println("------------------");

		System.out.println("Withdraw(15000)");
		result = current.withdraw(15000);
		if (result) {
			System.out.println("Transaction Success");
		} else
			System.out.println("Transaction Failed");
		System.out.println("Balance :: " + current.getBalance()); //0
		System.out.println("Overdraft Balance :: " + current.getOverdraftBalance());//40000
		System.out.println("------------------");

		System.out.println("Deposit(5000)");
		result = current.deposit(5000);
		if (result) {
			System.out.println("Transaction Success");
		} else
			System.out.println("Transaction Failed");
		System.out.println("Balance :: " + current.getBalance()); //0
		System.out.println("Overdraft Balance :: " + current.getOverdraftBalance()); // 45000
		System.out.println("------------------");

		System.out.println("Deposit(20000)");
		result = current.deposit(20000);
		if (result) {
			System.out.println("Transaction Success");
		} else
			System.out.println("Transaction Failed");
		System.out.println("Balance :: " + current.getBalance()); //15000
		System.out.println("Overdraft Balance :: " + current.getOverdraftBalance());//50000
		System.out.println("------------------");
	}
}
