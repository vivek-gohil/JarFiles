package com.fis.main;

import java.util.Scanner;

import com.fis.pojo.Circle;

//Client
public class CircleMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		int radius;

		System.out.println("Enter Radius");
		radius = scanner.nextInt();

		Circle circle = new Circle();
		double result = circle.area(radius);
		System.out.println("Area of circle :: " + result);

		System.out.println("---------------");
		System.out.println("Area of circle :: " + circle.area(radius));

		System.out.println("Back to main");

	}
}
