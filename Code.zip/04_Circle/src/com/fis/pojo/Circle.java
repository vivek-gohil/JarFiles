package com.fis.pojo;

//Server : Business Logic
public class Circle {

	// function with param.
	public double area(int radius) {
		double area = 3.14 * radius * radius;
		return area;
	}
}
