package com.fis.pojo;

public class Employee {
	private int employeeId;
	private String name;
	private double salary;

	// default constructor
	public Employee() {
		System.out.println("Default constructor of Employee");
	}

	// overloaded constructor (Parameterized constructor)
	public Employee(int employeeId, String name, double salary) {
		this.employeeId = employeeId;
		this.name = name;
		this.salary = salary;
	}

	// getters and setters
	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	
}
