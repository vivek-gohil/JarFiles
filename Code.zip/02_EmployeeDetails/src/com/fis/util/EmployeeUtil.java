package com.fis.util;

import com.fis.pojo.Employee;

public class EmployeeUtil {

	public void getNumber(int num) {
		System.out.println("-----------Start-----------");
		System.out.println("We are in getNumber");
		System.out.println(num);
		num = num + 10;
		System.out.println("New Value of num is :: " + num);
		System.out.println("-----------End-----------");

	}

	public void getEmployee(Employee employee) {
		System.out.println("------------Start------------");
		System.out.println("We are in getemployee()");
		System.out.println(employee);
		employee.setSalary(200);
		System.out.println("New Value of employee");
		System.out.println(employee);
		System.out.println("-----------End-----------");
	}
}
