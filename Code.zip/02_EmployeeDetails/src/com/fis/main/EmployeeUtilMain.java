package com.fis.main;

import java.util.Scanner;

import com.fis.pojo.Employee;
import com.fis.util.EmployeeUtil;

public class EmployeeUtilMain {

	public static void main(String[] args) {
		EmployeeUtil employeeUtil = new EmployeeUtil();
//		Scanner scanner = new Scanner(System.in);
//
//		System.out.println("Enter number");
//		int num = scanner.nextInt();
//
//		// call by value - copy is created
//		employeeUtil.getNumber(num);
//		System.out.println("Back to main");
//		System.out.println("Vale of num = " + num);

		Employee employee = new Employee(1, "Test", 100);
		//Call by reference - it dont create copy
		employeeUtil.getEmployee(employee);
		System.out.println("Back to main");
		System.out.println("Value in main");
		System.out.println(employee);

	}

}
