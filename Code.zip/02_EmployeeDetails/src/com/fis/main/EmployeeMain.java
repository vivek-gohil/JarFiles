package com.fis.main;

import java.util.Scanner;

import com.fis.pojo.Employee;

public class EmployeeMain {

	public static void main(String[] args) {
		Employee employeeOne = new Employee(101, "Fathima Mehraj", 1000);

		System.out.println(employeeOne);

	}

}
