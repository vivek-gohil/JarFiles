package com.fis.main;

import com.fis.pojo.Employee;

public class EmployeeMainV2 {

	public static void main(String[] args) {
		Employee e1 = new Employee(1, "Test", 1000);

		System.out.println("Values of e1");
		System.out.println(e1);
		System.out.println("Address of e1");
		System.out.println(e1.hashCode());

		Employee e2 = null;
		e2 = e1;
		System.out.println("Values of e2");
		System.out.println(e2);
		System.out.println("Address of e2");
		System.out.println(e2.hashCode());

		System.out.println("---------");
		System.out.println("Using e2 changing the salary");
		e2.setSalary(2000);
		System.out.println("---------");
		System.out.println("Values of e1");
		System.out.println(e1);
		System.out.println("Values of e2");
		System.out.println(e2);

	}

}
