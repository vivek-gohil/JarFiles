package com.fis.main;

import com.fis.pojo.Employee;

public class EmployeeArrayMain {
	public static void main(String[] args) {
		Employee[] employees = new Employee[4];

		employees[0] = new Employee(1, "Test1", 100);
		employees[1] = new Employee(2, "Test2", 100);
		employees[2] = new Employee(3, "Test3", 100);
		employees[3] = new Employee(4, "Test4", 100);

		System.out.println("Employee Array");
		System.out.println(employees[0]);
		System.out.println(employees[1]);
		System.out.println(employees[2]);
		System.out.println(employees[3]);
	}
}
