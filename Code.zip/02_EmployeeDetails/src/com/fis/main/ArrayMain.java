package com.fis.main;

import java.util.Scanner;

public class ArrayMain {
	public static void main(String[] args) {
		
		int[] num = new int[5];

		num[0] = 10;
		num[1] = 6;
		num[2] = 11;
		num[3] = 4;
		num[4] = 5;

		System.out.println("Values from array");
		System.out.println(num[0]);
		System.out.println(num[1]);
		System.out.println(num[2]);
		System.out.println(num[3]);
		System.out.println(num[4]);

		// Accept 5 numbers from user and store in array num and print the numbers from
		// array.
		int n;
		Scanner scanner = new Scanner(System.in);
		for (int i = 0; i < num.length; i++) {
			System.out.println("Enter Number");
			n = scanner.nextInt();
			num[i] = n;
		}

		System.out.println("---------------");
		for (int i = 0; i < num.length; i++) {
			System.out.println(num[i]);
		}
	}
}
