package com.fis.main;

import java.util.Scanner;

import com.fis.pojo.Number;

public class NumbersMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n1, n2, n3;

		System.out.println("Enter 3 number to find max");
		n1 = scanner.nextInt();
		n2 = scanner.nextInt();
		n3 = scanner.nextInt();

		Number number = new Number();
		System.out.println("Max is :: " + number.findMax(n1, n2, n3));

	}
}
