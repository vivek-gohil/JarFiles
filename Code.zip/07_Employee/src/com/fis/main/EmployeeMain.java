package com.fis.main;

import java.util.Scanner;

import com.fis.pojo.Employee;
import com.fis.util.EmployeeUtil;

public class EmployeeMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		int employeId;
		String name;
		double salary;

		System.out.println("Enter emloyeeId");
		employeId = scanner.nextInt();
		System.out.println("Enter Name");
		name = scanner.next();
		System.out.println("Enter Salary");
		salary = scanner.nextDouble();

		EmployeeUtil employeeUtil = new EmployeeUtil();
		Employee e = employeeUtil.createEmployee(employeId, name, salary);

		System.out.println("Employee Id " + e.getEmployeeId());
		System.out.println("Name :: " + e.getName());
		System.out.println("Salary ::" + e.getSalary());

	}
}
