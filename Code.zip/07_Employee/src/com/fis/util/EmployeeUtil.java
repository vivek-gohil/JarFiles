package com.fis.util;

import com.fis.pojo.Employee;

public class EmployeeUtil {

	public Employee createEmployee(int employeeId, String name, double salary) {
		Employee employee = new Employee(employeeId, name, salary);
		return employee;
	}

}
