package com.fis.main;

import java.util.Scanner;

import com.fis.util.EmployeeCRUD;

public class EmployeeCRUDMain {
	public static void main(String[] args) {

		EmployeeCRUD employeeCRUD = new EmployeeCRUD();
		employeeCRUD.getAllEmployees();
//		Scanner scanner = new Scanner(System.in);
//		int employeId;
//		String name;
//		double salary;
//
//		System.out.println("Enter emloyeeId");
//		employeId = scanner.nextInt();
//		System.out.println("Enter Name");
//		name = scanner.next();
//		System.out.println("Enter Salary");
//		salary = scanner.nextDouble();
//
//		boolean result = employeeCRUD.addNewEmployee(employeId, name, salary);
//		if (result)
//			System.out.println("Recored inserted successfully");
//		else
//			System.out.println("Failed to add new recored");
	}
}
