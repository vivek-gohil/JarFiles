package com.fis.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCConnectionTest {

	public static void main(String[] args) {

		try {
			//1. Load drivers
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver loaded successfully");
			//2. Creating connection between MYSQL and Java
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/fisdb", "root", "root#123");
			if (connection != null) {
				System.out.println("Connection Success");
				connection.close();
			}
		} catch (ClassNotFoundException e) {
			System.out.println("Exception : Driver not found ");
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			System.out.println("Exception : Connection faild");
			System.out.println(e.getMessage());
		}

	}

}
