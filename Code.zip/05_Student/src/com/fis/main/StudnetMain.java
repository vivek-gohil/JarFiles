package com.fis.main;

import java.util.Scanner;

import com.fis.pojo.Student;

public class StudnetMain {

	public static void main(String[] args) {
		int sub1, sub2, sub3, sub4, sub5;
		Scanner scanner = new Scanner(System.in);

		System.out.println("Enter Marks of sub1");
		sub1 = scanner.nextInt();
		System.out.println("Enter Marks of sub2");
		sub2 = scanner.nextInt();
		System.out.println("Enter Marks of sub3");
		sub3 = scanner.nextInt();
		System.out.println("Enter Marks of sub4");
		sub4 = scanner.nextInt();
		System.out.println("Enter Marks of sub5");
		sub5 = scanner.nextInt();

		Student student = new Student();

		System.out.println("Sum of all subjects :: " + student.total(sub1, sub2, sub3, sub4, sub5));
		System.out.println("Avg marks :: " + student.average());

	}

}
