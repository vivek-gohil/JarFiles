package com.fis.pojo;

public class Student {

	private int sumOfMarks;
	private double avgOfMarks;

	public int total(int sub1, int sub2, int sub3, int sub4, int sub5) {
		sumOfMarks = sub1 + sub2 + sub3 + sub4 + sub5;
		return sumOfMarks;
	}

	public double average() {
		avgOfMarks = sumOfMarks / 5;
		return avgOfMarks;
	}
}
