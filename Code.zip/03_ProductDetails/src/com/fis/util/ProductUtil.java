package com.fis.util;

import com.fis.pojo.Product;

public class ProductUtil {
	private Product[] products = new Product[5];
	private int length = 0;

	public void addNewProduct(Product product) {
		if (length < 5) {
			products[length] = product;
			length = length + 1;
		}
	}

	public void printProducts() {
		for (int i = 0; i < products.length; i++) {
			System.out.println(products[i]);
		}
	}
}
