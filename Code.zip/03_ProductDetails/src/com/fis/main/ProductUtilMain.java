package com.fis.main;

import java.util.Scanner;

import com.fis.pojo.Product;
import com.fis.util.ProductUtil;

public class ProductUtilMain {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		ProductUtil productUtil = new ProductUtil();

		int productId;
		String name;
		double price;

		for (int i = 0; i < 5; i++) {
			System.out.println("Enter productId");
			productId = scanner.nextInt();
			System.out.println("Enter Name");
			name = scanner.next();
			System.out.println("Enter Price");
			price = scanner.nextDouble();

			Product product = new Product(productId, name, price);
			productUtil.addNewProduct(product);
		}

		System.out.println("All Products");
		productUtil.printProducts();

	}
}
